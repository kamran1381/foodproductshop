
import React, { useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import './SignUpform.css';

export default function SignUpForm() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleFormSubmit = async (e) => {
    e.preventDefault();

    if (isSubmitted) {
      return;
    }

    const form = e.target;
    const formData = new FormData(form);

    let UserInfoObject = {
      role: 'User',
      id: uuidv4(),
    };

    formData.forEach((value, key) => {
      UserInfoObject[key] = value;
    });

    try {
      const response = await fetch('http://localhost:3500/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(UserInfoObject),
      });

      if (response.ok) {
        console.log('User data posted successfully!');

        form.reset(); // Reset the form

        setIsSubmitted(true); // Mark the form as submitted
      } else {
        console.log('Failed to post user data.');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const isFormValid = !isSubmitted; 

  return (
    <div className="container">
      <div className="card">
        <div className="card_title">
          <h1>Create Account</h1>
          <span>
            Already have an account? <a href="login">Sign In</a>
          </span>
        </div>
        <div className="form">
          <form method="post" id="signup-form" onSubmit={handleFormSubmit}>
            <input type="text" name="role"  value="User" style={{ display: 'none' }} />
            <input type="text" name="id" value={uuidv4()} style={{ display: 'none' }} />
            <input type="text" name="FirstName" placeholder="FirstName" disabled={isSubmitted} />
            <input type="text" name="LastName" placeholder="LastName" disabled={isSubmitted} />
            <input type="email" name="Email" placeholder="Email" disabled={isSubmitted} />
            <input type="password" name="Password" placeholder="Password" disabled={isSubmitted} />
            <button type="submit" disabled={!isFormValid}>
              Sign Up
            </button>
          </form>
        </div>
        <div className="card_terms">
          <input type="checkbox" name="" id="terms" />{' '}
          <span>
            I have read and agree to the <a href="">Terms of Service</a>
          </span>
        </div>
      </div>
    </div>
  );
}
