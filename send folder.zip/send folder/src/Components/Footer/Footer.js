import React from 'react'
import Newssettler from '../NewsSettler/Newssettler'

export default function Footer() {
  return (
    <div>
        <Newssettler/>
       
    </div>
  )
}
